"""Blade Agent Kit —— Headless 结构化输出示例。

Headless 模式让智能体"干完一件事就返回结构化结果"，不需要人来回交互，
适合把 Blade Agent 当成一个后端函数来调用（如批处理、数据抽取）。

run() 内部会：新建会话 -> 以 headless=True 发起对话 -> 等待 chat:end ->
按 schema 返回 dict（无 schema 时返回字符串）。

运行前设置环境变量：
    export BLADE_AGENT_URL=http://124.174.10.212:8020
    export BLADE_AGENT_TOKEN=sk-blade-你的token
"""

import asyncio
import os

from blade_agent_kit import BladeAgentClient


async def main() -> None:
    base_url = os.environ.get("BLADE_AGENT_URL", "http://124.174.10.212:8020")
    token = os.environ["BLADE_AGENT_TOKEN"]

    # 用 JSON Schema 约束返回结构；智能体必须产出符合该结构的结果
    schema = {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "城市名"},
            "country": {"type": "string", "description": "所属国家"},
        },
        "required": ["city", "country"],
    }

    async with BladeAgentClient(base_url, token=token) as client:
        # client.headless 是 HeadlessRunner；run() 返回结构化 dict
        result = await client.headless.run(
            "请给出巴黎所在的城市名和国家，并按要求的结构返回。",
            schema=schema,
            timeout_secs=300.0,
        )
        print("结构化结果：", result)

        # 不传 schema 时返回纯文本
        text = await client.headless.run("用一句话说明什么是 REST API。")
        print("文本结果：", text)


if __name__ == "__main__":
    asyncio.run(main())
