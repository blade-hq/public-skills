"""Blade Agent Kit —— 会话文件与会话技能示例。

演示会话工作区的文件读写、目录列举，以及给单个会话临时上传技能。

运行前设置环境变量：
    export BLADE_AGENT_URL=http://124.174.10.212:8020
    export BLADE_AGENT_TOKEN=sk-blade-你的token
"""

import asyncio
import os
import tempfile
from pathlib import Path

from blade_agent_kit import BladeAgentClient


async def main() -> None:
    base_url = os.environ.get("BLADE_AGENT_URL", "http://124.174.10.212:8020")
    token = os.environ["BLADE_AGENT_TOKEN"]

    async with BladeAgentClient(base_url, token=token) as client:
        session = await client.create_session(intent="文件与技能演示")
        try:
            # 1) 准备一个本地文件并上传到会话工作区根目录
            local = Path(tempfile.gettempdir()) / "hello.txt"
            local.write_text("你好，Blade Agent", encoding="utf-8")
            uploaded = await client.upload_file(session.id, local, dir_path=".")
            print("已上传：", uploaded.uploaded, "失败：", uploaded.failed)

            # 2) 列举工作区根目录
            entries = await client.list_dir(session.id, ".")
            for entry in entries:
                kind = "目录" if entry.is_dir else "文件"
                print(f"  [{kind}] {entry.name}")

            # 3) 下载刚上传的文件，校验内容（返回 bytes）
            data = await client.download_file(session.id, "hello.txt")
            print("下载内容：", data.decode("utf-8"))

            # 4) 给这个会话临时上传一个技能（仅对当前会话可见）
            # 技能名必须是 "命名空间/名字" 格式（后端校验 ^[a-z0-9-]+/[a-z0-9-]+$）
            skill = await client.upload_session_skill(
                session.id,
                name="demo/skill",
                files=[
                    {
                        "path": "SKILL.md",
                        "content": "---\nname: demo/skill\n---\n演示用技能。",
                    }
                ],
            )
            print(f"技能已上传：{skill.name}（{skill.file_count} 个文件）")

            # 5) 查看会话检查点（用于回溯 / rewind）
            checkpoints = await client.get_checkpoints(session.id)
            print("检查点数量：", len(checkpoints.items))
        finally:
            await client.delete_session(session.id)
            print("已删除会话：", session.id)


if __name__ == "__main__":
    asyncio.run(main())
