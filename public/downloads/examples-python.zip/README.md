# Python 示例（blade-agent-kit）

用 Python 异步 SDK 对接 Blade Agent 后端的最小示例。

## 前置

- Python **3.12**（SDK 约束 `>=3.12,<3.13`，用 3.13 会安装失败）
- 一个可连的后端（本手册用已部署实例 `http://124.174.10.212:8020`）
- 一个 API Token（在后端 Web 的 `/env` 页创建，以 `sk-blade-` 开头）

## 安装

推荐用 uv 建一个 3.12 环境：

```bash
uv venv --python 3.12 .venv
# 在线
uv pip install --python .venv/Scripts/python.exe blade-agent-kit==1.0.14
# 或离线（用本仓库 packages/ 下的 wheel）
uv pip install --python .venv/Scripts/python.exe ../../packages/blade_agent_kit-1.0.14-py3-none-any.whl
```

也可用 pip（前提当前 python 是 3.12）：

```bash
pip install -r requirements.txt
```

## 配置

```bash
export BLADE_AGENT_URL=http://124.174.10.212:8020
export BLADE_AGENT_TOKEN=sk-blade-你的token
```

Windows PowerShell：

```powershell
$env:BLADE_AGENT_URL = "http://124.174.10.212:8020"
$env:BLADE_AGENT_TOKEN = "sk-blade-你的token"
```

## 运行

```bash
python quickstart.py            # 建会话 + 流式对话
python headless_demo.py         # Headless 结构化输出
python files_and_skills_demo.py # 会话文件读写 + 会话技能
```

## 说明

- `BladeAgentClient` 是**异步上下文管理器**，务必用 `async with`，退出时会自动关闭连接。
- Token **必须在构造时注入**（`token=` 或环境变量 `BLADE_AGENT_TOKEN`），空 Token 会直接抛 `ValueError`。
- 流式对话走 **Socket.IO**，`chat()` 是异步事件迭代器，逐条产出 `turn:start / turn:patch / turn:end / chat:end`。
