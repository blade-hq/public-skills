"""Blade Agent Kit —— Python 最小示例。

演示：连接后端 -> 创建会话 -> 流式对话 -> 清理会话。

运行前先设置环境变量（Token 在 Web 的 /env 页创建，以 sk-blade- 开头）：
    export BLADE_AGENT_URL=http://124.174.10.212:8020
    export BLADE_AGENT_TOKEN=sk-blade-你的token

运行（需 Python 3.12，SDK 约束 >=3.12,<3.13）：
    python quickstart.py
"""

import asyncio
import os

from blade_agent_kit import BladeAgentClient, ChatEnd, SystemError, TurnPatch


async def main() -> None:
    base_url = os.environ.get("BLADE_AGENT_URL", "http://124.174.10.212:8020")
    token = os.environ["BLADE_AGENT_TOKEN"]  # 缺失会直接抛错，避免静默失败

    # BladeAgentClient 是异步上下文管理器，退出时自动关闭 REST 与 Socket.IO 连接
    async with BladeAgentClient(base_url, token=token) as client:
        # 健康检查：确认后端可达（GET /api/health）
        print("后端健康状态：", await client.health())

        # 创建一个新会话；intent 是本次会话的目标描述
        session = await client.create_session(intent="AgentKit 快速上手")
        print("已创建会话：", session.id)

        try:
            # chat() 返回异步事件迭代器：逐条产出 turn:start / turn:patch / turn:end / chat:end
            async for event in client.chat(session.id, message="用一句话介绍你自己"):
                if isinstance(event, TurnPatch):
                    # 增量内容在 patch 里，data 结构随 patch_type 变化
                    print(f"[patch #{event.sequence}] {event.patch_type}")
                elif isinstance(event, ChatEnd):
                    print(f"[结束] status={event.status} finish_reason={event.finish_reason}")
                elif isinstance(event, SystemError):
                    print(f"[系统错误] {event.message}")
        finally:
            # 清理：删除会话（DELETE /api/sessions/{id}）
            await client.delete_session(session.id)
            print("已删除会话：", session.id)


if __name__ == "__main__":
    asyncio.run(main())
