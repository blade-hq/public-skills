<script setup lang="ts">
import { ref } from "vue"
import { useChat } from "./composables/useChat"

const { messages, isStreaming, errorText, send, stop } = useChat()
const draft = ref("")

function onSend() {
  const text = draft.value
  draft.value = ""
  void send(text)
}
</script>

<template>
  <main class="page">
    <h1>Blade Agent · Vue 示例</h1>
    <p class="hint">用 @blade-hq/agent-kit/client 直连后端，自建聊天界面。</p>

    <section class="messages">
      <div v-for="(m, i) in messages" :key="i" :class="['bubble', m.role]">
        <span class="role">{{ m.role === "user" ? "我" : "助手" }}</span>
        <div class="text">{{ m.text }}</div>
      </div>
      <p v-if="isStreaming" class="streaming">正在生成…</p>
      <p v-if="errorText" class="error">{{ errorText }}</p>
    </section>

    <form class="composer" @submit.prevent="onSend">
      <input
        v-model="draft"
        placeholder="输入消息，回车发送"
        :disabled="isStreaming"
      />
      <button type="submit" :disabled="isStreaming || !draft.trim()">发送</button>
      <button type="button" :disabled="!isStreaming" @click="stop">停止</button>
    </form>
  </main>
</template>

<style scoped>
.page {
  max-width: 720px;
  margin: 0 auto;
  padding: 24px;
  font-family: system-ui, sans-serif;
}
.hint {
  color: #666;
  font-size: 14px;
}
.messages {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 240px;
  margin: 16px 0;
}
.bubble {
  padding: 8px 12px;
  border-radius: 8px;
  max-width: 80%;
}
.bubble.user {
  align-self: flex-end;
  background: #e8f0fe;
}
.bubble.assistant {
  align-self: flex-start;
  background: #f3f4f6;
}
.role {
  font-size: 12px;
  color: #888;
}
.text {
  white-space: pre-wrap;
}
.streaming {
  color: #2563eb;
  font-size: 14px;
}
.error {
  color: #dc2626;
  font-size: 14px;
}
.composer {
  display: flex;
  gap: 8px;
}
.composer input {
  flex: 1;
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 6px;
}
.composer button {
  padding: 8px 16px;
  border: none;
  border-radius: 6px;
  background: #2563eb;
  color: #fff;
  cursor: pointer;
}
.composer button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>
