// Vue 用 @blade-hq/agent-kit 的 /client 子包（纯网络客户端，不依赖 React）。
// 这里创建一个全局单例 BladeClient，供全应用复用。
import { BladeClient } from "@blade-hq/agent-kit/client"

// Token 必须在构造时注入（Bearer 模式）。
// 首方 Web 若走 cookie 会话，可不传 token；这里演示第三方 Token 接入。
export const blade = new BladeClient({
  baseUrl: import.meta.env.VITE_BLADE_URL,
  token: import.meta.env.VITE_BLADE_TOKEN,
})
