// useChat —— Vue 组合式封装，复刻 React 版 useChat 的核心能力：
// 建会话 -> 通过 Socket.IO 流式对话 -> 把投影(TurnProjection)里的文本渲染出来。
//
// 关键时序（与 SDK 内部一致）：
//   socket 连接(auth 自动带 token) -> emit "session:subscribe" -> emit "chat:send"
//   监听 "turn:start" / "turn:patch" / "turn:end" / "chat:end" / "system:error"
//
// turn:patch 的 data.turn 携带的是"当前完整投影快照"（非增量），
// 因此每次 patch 直接用 data.turn 的文本块整体替换，即可实现流式渲染。
import type { ChatSendPayload } from "@blade-hq/agent-kit/client"
import { ref, shallowRef } from "vue"
import { blade } from "../blade"

export interface ChatMessage {
  role: "user" | "assistant"
  text: string
}

// 从一个 TurnProjection 里抽取纯文本（拼接所有 type==="text" 的块）。
// content 类型是 unknown，这里做防御式读取。
function extractText(turn: unknown): string {
  if (!turn || typeof turn !== "object") return ""
  const blocks = (turn as { blocks?: unknown }).blocks
  if (!Array.isArray(blocks)) return ""
  const parts: string[] = []
  for (const block of blocks) {
    if (block && typeof block === "object" && (block as { type?: unknown }).type === "text") {
      const content = (block as { content?: unknown }).content
      if (typeof content === "string") parts.push(content)
    }
  }
  return parts.join("")
}

export function useChat() {
  const messages = ref<ChatMessage[]>([])
  const isStreaming = ref(false)
  const errorText = ref<string | null>(null)
  // 会话 id 跨多轮对话复用
  const sessionId = shallowRef<string | null>(null)
  // 强类型 socket（Socket<ServerToClientEvents, ClientToServerEvents>）
  const socket = blade.socket()

  // 注册一次事件监听；每一轮对话都复用同一 socket。
  socket.on("turn:patch", (payload) => {
    // payload.data.turn 是当前完整投影快照
    const turn = (payload.data as { turn?: unknown } | undefined)?.turn
    const text = extractText(turn)
    if (text) upsertAssistant(text)
  })
  socket.on("turn:end", (payload) => {
    const text = extractText(payload)
    if (text) upsertAssistant(text)
  })
  socket.on("chat:end", () => {
    isStreaming.value = false
  })
  socket.on("system:error", (payload) => {
    errorText.value = (payload as { message?: string }).message ?? "系统错误"
    isStreaming.value = false
  })

  // SDK 的 socket 以 autoConnect:false 创建（Token 已通过 auth 注入），
  // 使用 /client 子包时必须由消费方显式发起连接，否则 emit 全部被缓冲、后端收不到。
  // 连接握手期间的 emit 会被 socket.io 自动排队，握手完成后立即冲刷。
  socket.connect()

  // 把助手消息更新为最新文本（流式期间不断替换最后一条 assistant 消息）。
  function upsertAssistant(text: string) {
    const last = messages.value[messages.value.length - 1]
    if (last && last.role === "assistant") {
      last.text = text
    } else {
      messages.value.push({ role: "assistant", text })
    }
  }

  async function send(text: string) {
    if (!text.trim() || isStreaming.value) return
    errorText.value = null
    messages.value.push({ role: "user", text })
    isStreaming.value = true

    // 首轮先建会话
    if (!sessionId.value) {
      const created = await blade.sessions.createSession(text)
      sessionId.value = created.session_id
    }
    const sid = sessionId.value

    // 订阅该会话，再发送消息
    socket.emit("session:subscribe", { session_id: sid })
    // 注意：SDK 自动生成的类型把 message 误标为对象，后端与 Python SDK 实际接受字符串，
    // 这里按运行时真实契约传字符串，并做一次类型断言。
    socket.emit("chat:send", {
      session_id: sid,
      message: text,
    } as unknown as ChatSendPayload)
  }

  async function stop() {
    const sid = sessionId.value
    if (!sid) return
    socket.emit("chat:stop", { session_id: sid }, () => {})
    isStreaming.value = false
  }

  return { messages, isStreaming, errorText, sessionId, send, stop }
}
