import vue from "@vitejs/plugin-vue"
import { defineConfig } from "vite"

// Vue 3 + Vite。开发端口随意，这里用 5180。
export default defineConfig({
  plugins: [vue()],
  server: { port: 5180 },
})
