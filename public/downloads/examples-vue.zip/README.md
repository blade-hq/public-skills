# Vue 示例（@blade-hq/agent-kit/client）

Vue 3 + Vite，用 `@blade-hq/agent-kit` 的 **`/client`** 子包（纯网络客户端，不依赖 React）
直连 Blade Agent 后端，自建聊天界面。

> Vue 只能用 `/client`。`/react` 里的 `ChatView`、`useChat` 等是 React 绑定，Vue 中不可用。

## 前置

- Node 18+ / pnpm
- 后端 `http://124.174.10.212:8020` + 一个 `sk-blade-` Token（后端 Web `/env` 页创建）

## 配置

```bash
cp .env.example .env.local
# 编辑 .env.local，填入 VITE_BLADE_URL 与 VITE_BLADE_TOKEN
```

## 安装与运行

```bash
pnpm install
pnpm dev        # http://localhost:5180
pnpm typecheck  # 类型检查
pnpm build      # 生产构建
```

## 关键点

- `src/blade.ts`：创建全局 `BladeClient` 单例，Token 构造时注入。
- `src/composables/useChat.ts`：用 `blade.socket()` 拿强类型 socket，按
  `session:subscribe` → `chat:send` 发起，监听 `turn:patch` / `turn:end` / `chat:end`。
- 流式渲染：`turn:patch` 的 `data.turn` 是**当前完整投影快照**，每次取其文本块整体替换即可。
