import { bootstrapBladeClient, BladeClientProvider } from "@blade-hq/agent-kit/react"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import { Toaster } from "sonner"
// 使用 /chat、/session 等预制 React UI 时，入口必须导入这份样式。
import "@blade-hq/agent-kit/style.css"
import { App } from "./App"

// 装配全局 BladeClient（Bearer Token 构造时注入）。
// bootstrapBladeClient 会把 client 挂到 SDK 内部 stores，供 hooks / api 使用。
const client = bootstrapBladeClient({
  baseUrl: import.meta.env.VITE_BLADE_URL,
  token: import.meta.env.VITE_BLADE_TOKEN,
})

const queryClient = new QueryClient()

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <BladeClientProvider client={client}>
        <App />
        <Toaster />
      </BladeClientProvider>
    </QueryClientProvider>
  </StrictMode>,
)
