import { ChatView } from "@blade-hq/agent-kit/chat"
import { sessionsApi, useSessionStore } from "@blade-hq/agent-kit/react"
import { useState } from "react"

// 最小 React 示例：点按钮新建会话，然后用预制 ChatView 渲染完整聊天界面。
// ChatView 内部已处理：会话数据、Socket.IO 流式、历史加载、输入框、技能状态、滚动。
export function App() {
  const [sessionId, setSessionId] = useState<string | null>(null)
  const [creating, setCreating] = useState(false)

  async function createSession() {
    setCreating(true)
    try {
      const { session_id } = await sessionsApi.createSession("React 示例")
      // 关键：把新会话设为活跃会话。SDK 据此让 socket 订阅该会话房间（full 模式），
      // 才能接收 turn:start/turn:patch/turn:end 流式事件；否则 ChatView 永远停在"发送中"。
      useSessionStore.getState().setActiveSession(session_id)
      setSessionId(session_id)
    } finally {
      setCreating(false)
    }
  }

  if (!sessionId) {
    return (
      <div style={{ padding: 24, fontFamily: "system-ui, sans-serif" }}>
        <h1>Blade Agent · React 示例</h1>
        <p style={{ color: "#666" }}>用 @blade-hq/agent-kit/react 的预制 ChatView 渲染聊天。</p>
        <button type="button" onClick={createSession} disabled={creating}>
          {creating ? "创建中…" : "新建会话"}
        </button>
      </div>
    )
  }

  return (
    <div style={{ height: "100vh", display: "flex", flexDirection: "column" }}>
      <ChatView sessionId={sessionId} />
    </div>
  )
}
