import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"

// React 19 + Vite。开发端口用 5170。
export default defineConfig({
  plugins: [react()],
  server: { port: 5170 },
})
