/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_BLADE_URL: string
  readonly VITE_BLADE_TOKEN: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
