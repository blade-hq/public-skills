# React 示例（@blade-hq/agent-kit/react）

React 19 + Vite，用 `@blade-hq/agent-kit` 的 **`/react`** 子包，直接复用预制的
`ChatView` 组件——它内置了会话数据、Socket.IO 流式、历史加载、输入框、技能状态与滚动。

## 前置

- Node 18+ / pnpm
- 后端 `http://124.174.10.212:8020` + 一个 `sk-blade-` Token（后端 Web `/env` 页创建）

## 配置

```bash
cp .env.example .env.local
# 编辑 .env.local，填入 VITE_BLADE_URL 与 VITE_BLADE_TOKEN
```

## 安装与运行

```bash
pnpm install
pnpm dev        # http://localhost:5170
pnpm typecheck  # 类型检查
pnpm build      # 生产构建
```

## 关键点

- **peer 依赖**：`react` `react-dom` `@tanstack/react-query` `sonner` 必须一起安装。
- **样式**：使用 `/chat`、`/session` 等预制 UI 时，入口 **必须** `import "@blade-hq/agent-kit/style.css"`。
- **装配**：`bootstrapBladeClient({ baseUrl, token })` 建立全局 client（Token 构造时注入），
  再用 `BladeClientProvider` 包裹应用。
- **自建界面**：若不用 ChatView，可直接用 `useChat(sessionId)` 拿 `messages / send / stop`，
  自行渲染。
